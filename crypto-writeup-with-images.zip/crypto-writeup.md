# CryptoHack Cryptography Challenge Write-ups

A structured collection of introductory CryptoHack solutions covering Python basics, ASCII, hexadecimal, JSON interaction, Base64, integer/byte conversion, and XOR cryptography.

> **Scope:** These notes have been edited for readability and consistency from the original document. Screenshots and embedded images are retained in the `images/` directory. Run network-based examples only against the intended CTF challenge service.

## Table of Contents

1. [Introduction to Python and XOR](#1-introduction-to-python-and-xor)
2. [ASCII Values](#2-ascii-values)
3. [Hexadecimal to Bytes](#3-hexadecimal-to-bytes)
4. [JSON Interaction](#4-json-interaction)
5. [Base64 Encoding](#5-base64-encoding)
6. [Converting Integers to Bytes](#6-converting-integers-to-bytes)
7. [XOR Basics](#7-xor-basics)
8. [XOR Properties and Multi-Key XOR](#8-xor-properties-and-multi-key-xor)
9. [Single-Byte XOR Brute Force](#9-single-byte-xor-brute-force)
10. [Key Takeaways](#10-key-takeaways)

---

## 1. Introduction to Python and XOR

This challenge introduces a short Python program that decodes a list of integer values by XORing each value with `0x32`, then converting the result to a character.

```python
#!/usr/bin/env python3
import sys

if sys.version_info.major == 2:
    print("You are running Python 2, which is no longer supported. Please update to Python 3.")

ords = [81, 64, 75, 66, 70, 93, 73, 72, 1, 92, 109, 2, 84, 109, 66,
        75, 70, 90, 2, 92, 79]

print("Here is your flag:")
print("".join(chr(o ^ 0x32) for o in ords))
```

### How it works

- `sys.version_info.major` checks the major Python version.
- `0x32` is the hexadecimal representation of decimal `50`.
- `o ^ 0x32` applies the XOR operation to each integer.
- `chr(...)` converts the resulting integer to a Unicode character.
- `"".join(...)` combines the characters without inserting separators.

**Flag:** `crypto{z3n_0f_pyth0n}`

### XOR and character conversion illustration

## 2. ASCII Values

ASCII represents characters using numeric values. In Python, `chr()` converts an integer into its corresponding character, while `ord()` converts a character into its integer value.

```python
ords = [99, 114, 121, 112, 116, 111, 123, 65, 83, 67, 73, 73,
        95, 112, 114, 49, 110, 116, 52, 98, 108, 51, 125]

print("".join(chr(o) for o in ords))
```

**Flag:** `crypto{ASCII_pr1nt4bl3}`

### Useful conversion functions

| Function | Purpose |
|---|---|
| `ord("A")` | Returns the integer value for a character (`65` for `A`) |
| `chr(65)` | Returns the character for an integer (`A`) |

The original notes include uppercase and lowercase ASCII-to-hex reference tables. The embedded images are retained in the image gallery below.

---

## 3. Hexadecimal to Bytes

Hexadecimal (base 16) uses the symbols `0–9` and `A–F`. Each pair of hexadecimal digits represents one byte.

```python
hex_string = (
    "63727970746f7b596f755f77696c6c5f62655f776f726b696e675f77697468"
    "5f6865785f737472696e67735f615f6c6f747d"
)

data = bytes.fromhex(hex_string)
print(data)
```

- `bytes.fromhex(hex_string)` converts hexadecimal text into bytes.
- `text.encode().hex()` converts text into bytes and then represents those bytes as hexadecimal.

**Flag:** `crypto{You_will_be_working_with_hex_strings_a_lot}`

---

## 4. JSON Interaction

One challenge uses a remote service and asks for a JSON object with the key `buy` and the value `flag`. The original notes show a Python client using `pwntools` and `json`.

A simplified example of the JSON payload is:

```python
request = {
    "buy": "flag"
}
```

JSON keys and values must match the challenge's expected format. The remote service's response should be read and interpreted according to the challenge prompt.

**Flag:** `crypto{sh0pp1ng_f0r_fl4g5}`

> The original document contains a screenshot of the supplied client and its terminal output. See the image gallery for the preserved screenshots.

---

## 5. Base64 Encoding

Base64 is a binary-to-text encoding scheme that represents binary data using a 64-character alphabet. It is an encoding format, not encryption.

```python
import base64

hex_data = "72bca9b68fc16ac7beeb8f849dca1d8a783e8acf9679bf9269f7bf"
data = bytes.fromhex(hex_data)
encoded = base64.b64encode(data)

print(encoded)
```

- `bytes.fromhex(...)` converts hexadecimal text into bytes.
- `base64.b64encode(...)` encodes those bytes in Base64.

**Flag shown in the original notes:** `crypto/Base+64+Encoding+is+Web+Safe/`

---

## 6. Converting Integers to Bytes

Cryptographic algorithms often operate on integers, while messages are represented as bytes. PyCryptodome provides helper functions for converting between these forms.

Install the dependency if needed:

```bash
python -m pip install pycryptodome
```

Example:

```python
from Crypto.Util.number import long_to_bytes

key = 11515195063862318899931685488813747395775516287289682636499965282714637259206269
flag = long_to_bytes(key)
print(flag)
```

- `long_to_bytes(n)` converts a non-negative integer into its byte representation.
- `bytes_to_long(data)` performs the reverse conversion.

**Flag shown in the original notes:** `crypto{3nc0d1n6_4ll_7h3_w4y_d0wn}`

---

## 7. XOR Basics

XOR (exclusive OR) is a bitwise operation. For each bit position, the result is `1` when the two input bits differ and `0` when they are the same.

| A | B | A XOR B |
|---:|---:|---:|
| 0 | 0 | 0 |
| 0 | 1 | 1 |
| 1 | 0 | 1 |
| 1 | 1 | 0 |

### Example: XOR a string with 13

```python
string = "label"
result = "".join(chr(ord(c) ^ 13) for c in string)
print(result)
```

For each character:

1. `ord(c)` converts the character to an integer.
2. `^ 13` XORs that integer with `13`.
3. `chr(...)` converts the result back to a character.
4. `"".join(...)` joins the resulting characters into one string.

### Numerical example

Let `a = 12` and `k = 5`.

```text
12 = 1100
 5 = 0101
------------
XOR  1001 = 9
```

Applying the same key again restores the original value:

```text
9 = 1001
5 = 0101
------------
XOR  1100 = 12
```

This works because XOR is self-inverse:

\[
(a \oplus k) \oplus k = a
\]

---

## 8. XOR Properties and Multi-Key XOR

The original notes use three XOR properties:

- **Commutative:** \(A \oplus B = B \oplus A\)
- **Associative:** \((A \oplus B) \oplus C = A \oplus (B \oplus C)\)
- **Self-inverse:** \(A \oplus A = 0\), and \(A \oplus 0 = A\)

These properties allow XOR operations to be rearranged when recovering a plaintext.

The source notes provide the following values:

```python
KEY1 = bytes.fromhex("a6c8b6733c9b22de7bc0253266a3867df55acde8635e19c73313")
KEY2_KEY3 = bytes.fromhex("c1545756687e7573db23aa1c3452a098b71a7fbf0fddddde5fc1")
data = bytes.fromhex("04ee9855208a2cd59091d04767ae47963170d1660df7f56f5faf")
```

The recovery equation is:

\[
\text{FLAG} = \text{data} \oplus \text{KEY1} \oplus (\text{KEY2} \oplus \text{KEY3})
\]

A byte-wise implementation can be written as:

```python
flag = bytes(
    d ^ k1 ^ k23
    for d, k1, k23 in zip(data, KEY1, KEY2_KEY3)
)
print(flag)
```

**Flag shown in the original notes:** `crypto{0x10_15_my_f4v0ur173_by7e}`

---

## 9. Single-Byte XOR Brute Force

When a ciphertext has been XORed with one unknown byte, there are only 256 possible key values (`0` through `255`). Testing each key is therefore practical.

```python
hex_data = "73626960647f6b206821204f21254f7d694f7624662065622127234f726927756d"
ciphertext = bytes.fromhex(hex_data)

for key in range(256):
    plaintext = bytes(b ^ key for b in ciphertext)

    if b"crypto{" in plaintext:
        print("Key:", key)
        print("Flag:", plaintext.decode(errors="replace"))
        break
```

### Workflow

1. Convert the hexadecimal ciphertext to bytes.
2. Try every possible single-byte key.
3. XOR each ciphertext byte with the candidate key.
4. Search the result for the expected `crypto{` prefix.
5. Print the matching key and plaintext.

**Flag shown in the original notes:** `crypto{0x10_15_my_f4v0ur173_by7e}`

---

## 10. Key Takeaways

- Use `ord()` and `chr()` to move between characters and integer values.
- Use `bytes.fromhex()` and `.hex()` for hexadecimal conversion.
- Base64 is encoding, not encryption.
- PyCryptodome's `long_to_bytes()` and `bytes_to_long()` help convert between integers and byte strings.
- XOR is self-inverse, which makes it useful in introductory cryptography exercises.
- A single-byte XOR key can be brute-forced by testing all 256 possibilities.
- Keep scripts, explanations, and screenshots together so a write-up can be reviewed and reproduced.

---

## Original Images and Screenshots

All embedded images from the source DOCX are included below. Image files are stored in the adjacent `images/` directory so the Markdown renders correctly in a repository such as GitHub.

### Reference image 1

![Reference image 1](images/image-01.png)

### Reference image 2

![Reference image 2](images/image-02.png)

### Reference image 3

![Reference image 3](images/image-03.png)

### Reference image 4

![Reference image 4](images/image-04.png)

### Reference image 5

![Reference image 5](images/image-05.png)

### Reference image 6

![Reference image 6](images/image-06.png)

### Reference image 7

![Reference image 7](images/image-07.png)

### Reference image 8

![Reference image 8](images/image-08.png)

### Reference image 9

![Reference image 9](images/image-09.png)

### Reference image 10

![Reference image 10](images/image-10.png)

### Reference image 11

![Reference image 11](images/image-11.png)

### Reference image 12

![Reference image 12](images/image-12.png)

### Reference image 13

![Reference image 13](images/image-13.png)

### Reference image 14

![Reference image 14](images/image-14.png)

### Reference image 15

![Reference image 15](images/image-15.png)

### Reference image 16

![Reference image 16](images/image-16.png)

### Reference image 17

![Reference image 17](images/image-17.png)

### Reference image 18

![Reference image 18](images/image-18.png)

### Reference image 19

![Reference image 19](images/image-19.png)

### Reference image 20

![Reference image 20](images/image-20.png)

### Reference image 21

![Reference image 21](images/image-21.png)

